<?php

   include_once 'config.php';
   
   $codigo           = $_REQUEST['codigo']; 
   $cpf              = $_REQUEST['cpf']; 
   $defeito          = $_REQUEST['defeito'];
   $descricao        = $_REQUEST['descricao'];
   $data_abertura    = date('Y-m-d');
   $valor            = $_REQUEST['valor'];
   $ativo            = "0";
       

   
 
   
   $sql = "INSERT INTO OrdemServico (codigo,defeito,descricao,cpf, ativo,valor,data_abertura)   
   VALUES ('$codigo', '$defeito', '$descricao', '$cpf','$ativo', '$valor', '$data_abertura')";

 

    if (mysqli_query($conn, $sql)) {
      echo "New record created successfully";
    } else {
      echo "Error: " . $sql . "<br>" . mysqli_error($conn);
    }
    
    mysqli_close($conn);
    ?>








