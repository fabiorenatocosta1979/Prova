<?php


   include_once "config.php";

   if(isset($_GET['id'])){

    $id = $_GET['id'];
    
    $sql = "DELETE FROM OrdemServico WHERE id = {$id} ";
     if($conn->query($sql) === true){
         echo "Cliente deletado com sucesso!";
     }else{
         echo "Não foi possível deletar o cliente!";
     }



   }

?>