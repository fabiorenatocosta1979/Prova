<?php

   include_once 'config.php';
   
   $nome            = $_REQUEST['nome'];
   $idade           = $_REQUEST['idade'];
   $foto            = '';
   $cpf             = $_REQUEST['cpf']; 
   $rg              = $_REQUEST['rg'];
   $email           = $_REQUEST['email'];
   $telefone        = $_REQUEST['telefone'];
   $endereco        = $_REQUEST['endereco'];
   $data_adicionado = date('Y-m-d');
       //extract($_POST);

   
 
   
   $sql = "INSERT INTO Cliente (nome, idade, foto, cpf, rg, email, telefone, endereco, data_adicionado)
   VALUES ('$nome', '$idade', '$foto', '$cpf', '$rg', '$email', '$telefone', '$endereco', '$data_adicionado')";

    if (mysqli_query($conn, $sql)) {
      echo "New record created successfully";
    } else {
      echo "Error: " . $sql . "<br>" . mysqli_error($conn);
    }
    
    mysqli_close($conn);
    ?>







