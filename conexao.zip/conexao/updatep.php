<?php 
 
 require_once("config.php");
 
   if(isset($_POST)) {
    $id        = $_POST['id'];
    $defeito   = $_POST['defeito'];
    $descricao = $_POST['descricao'];
    $valor     = $_POST['valor'];
   


 
    $sql = "UPDATE OrdemServico SET defeito = '$defeito', descricao = '$descricao', valor = '$valor' WHERE id = '$id' ";
   
if ($conn->query($sql) === TRUE) {
  echo "Record updated successfully";
} else {
  echo "Error updating record: " . $conn->error;
}

}
   
?>

