<?php 
 
 require_once("config.php");
 
   if(isset($_POST)) {
    $id = $_POST['id'];
    $nome = $_POST['nome'];
    $email = $_POST['email'];
    $telefone = $_POST['telefone'];
    $endereco = $_POST['endereco'];
    $idade    = $_POST['idade']; 

    


 
    $sql = "UPDATE Cliente SET nome = '$nome', email = '$email', idade = '$idade', telefone = '$telefone', endereco = '$endereco' WHERE id = '$id' ";
    if($conn->query($sql) === TRUE) {
       echo "Atualizado";
    } else {
        echo "Houve um erro ao atualizar dados! : ". $connect->error;
    }
 
}
   
?>