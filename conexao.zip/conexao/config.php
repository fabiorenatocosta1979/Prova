<?php
 
    $servidor = "localhost";
    $usuario  = "grupoq79_sistema";
    $senha    = "F!bio!@#$%";
    $dbname   = "grupoq79_condominios";   

  
// Create connection
$conn = new mysqli($servidor, $usuario, $senha, $dbname);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}
?>